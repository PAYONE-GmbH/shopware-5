<?php

/**
 * $Id: $
 */
class Shopware_Controllers_Backend_MoptSupportPayone extends Shopware_Controllers_Backend_ExtJs
{
  
}